
export const pt = {
          "title": "Phares",
          "content": "Connaissez les plus beaux phares du monde.",
          "figure": {
            "alt": "Photo de phare"
          }
    };

export const en = {
              "title": "Lighthouses",
              "content": "Know the most beautiful lighthouses of the world.",
              "figure": {
                "alt": "Lighthouse picture"
              }
    };

