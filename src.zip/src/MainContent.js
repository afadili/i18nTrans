import React from 'react';
import SubContent from './SubContent'

export default class MainContent extends React.Component {
  render(){
    return <div>
      <SubContent content="Mon texte de première partie" />
      <SubContent content="La seconde partie" />		  
      <SubContent content="Et la dernière partie !" />		  
    </div>
  }
}



