import React from 'react';

export default class HeadContent extends React.Component {
  render(){
    return <div>Mon Header en français</div>
  }
}


