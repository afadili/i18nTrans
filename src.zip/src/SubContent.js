import React from 'react';

export default class SubContent extends React.Component {
  render(){
    return <div>{this.props.content}</div>
  }
}



