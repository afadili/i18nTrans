import React from 'react';
import BodyContent from './BodyContent'
import { getI18n } from 'react-i18next'
import './App.css';
import i18n from './i18n';
import { Translation } from 'react-i18next';


class App extends React.Component {
  setLanguage(language) {
    getI18n().changeLanguage(language)
  }

  render(){	
    return (
      <div className="App">
        <Translation>
     {
       t => <h1>{t('title')}</h1>
     }
   </Translation>
        <span>{ i18n.language}La langue est en français {
          i18n.t("title")
        } </span>
        <select>{ ['en', 'pt'].map( language => 
          <option onClick={() => this.setLanguage(language)}>{language}</option>
        ) }</select>

        <BodyContent />
      </div>   
    )
  }	  
}

export default App;
