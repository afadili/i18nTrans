import React from 'react';

export default class FootContent extends React.Component {
  render(){
    return <div>Mon Footer en français</div>
  }
}



